
package tests;
import com.codeborne.selenide.Configuration;
import org.testng.annotations.Test;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Condition.*;
public class MobileTests {
 @Test public void mobileHome(){
  Configuration.browserSize="375x812";
  open("https://tbcbank.ge");
  $("header").shouldBe(visible);
 }
}
