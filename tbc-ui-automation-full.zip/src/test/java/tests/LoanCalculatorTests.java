
package tests;
import constants.Urls;
import org.testng.annotations.Test;
import pages.LoanCalculatorPage;
import static com.codeborne.selenide.Selenide.open;
public class LoanCalculatorTests extends BaseTest {
 LoanCalculatorPage page=new LoanCalculatorPage();
 @Test public void calculatorWorks(){
  open(Urls.LOAN_CALCULATOR);
  page.verifyVisible();
  page.enterAmount("10000");
  page.calculate();
  page.verifyResult();
 }
}
