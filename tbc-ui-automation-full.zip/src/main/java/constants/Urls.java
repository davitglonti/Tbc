
package constants;
public class Urls {
 public static final String LOCATIONS="https://tbcbank.ge/ka/atms&branches";
 public static final String LOAN_CALCULATOR="https://tbcbank.ge/ka/loans/consumer-loan/digital";
 public static final String DEPOSIT="https://tbcbank.ge/ka/deposits/my-goal-deposit";
}
