
package pages;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Condition.*;
public class DepositPage {
 public void verifyLoaded(){ $("h1").shouldBe(visible); }
 public void verifyCTA(){ $("button").shouldBe(visible); }
 public void verifyContent(){ $("body").shouldHave(text("ანაბარი")); }
}
