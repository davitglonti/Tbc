
package tests;
import constants.Urls;
import org.testng.annotations.Test;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Condition.*;
public class LocationsTests extends BaseTest {
 @Test public void openLocations(){
  open(Urls.LOCATIONS);
  $("body").shouldBe(visible);
 }
}
