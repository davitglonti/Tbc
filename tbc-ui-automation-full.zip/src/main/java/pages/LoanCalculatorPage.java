
package pages;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Condition.*;
public class LoanCalculatorPage {
 public void verifyVisible(){ $("body").shouldBe(visible); }
 public void enterAmount(String a){ $("input").setValue(a); }
 public void calculate(){ $("button").click(); }
 public void verifyResult(){ $("body").shouldHave(text("₾")); }
}
