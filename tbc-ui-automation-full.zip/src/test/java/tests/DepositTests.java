
package tests;
import constants.Urls;
import org.testng.annotations.Test;
import pages.DepositPage;
import static com.codeborne.selenide.Selenide.open;
public class DepositTests extends BaseTest {
 DepositPage page=new DepositPage();
 @Test public void depositPageWorks(){
  open(Urls.DEPOSIT);
  page.verifyLoaded();
  page.verifyCTA();
  page.verifyContent();
 }
}
